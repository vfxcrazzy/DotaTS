# DotaTS
Dota 2 reborn

SKIN -> https://github.com/ggassmann/spiritgate/blob/1a4f268a1131c67b8f1210bbcf00b48d5f96ff92/content/dota_addons/dawngatedota/panorama/scripts/custom_game/hero_selection.js
https://github.com/ggassmann/spiritgate