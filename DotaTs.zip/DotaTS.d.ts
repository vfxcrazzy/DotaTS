declare let DotaTS: DotaTS
declare let Utils: Utils
declare let MainMenu: MainMenu
declare let GameRules: any

interface DotaTS {
  Panels: any

  // Scripts: Map<string, Module>

  Init(): Promise<void>
  GetServer(): string
  ServerRequest(name?: string, path?: string, data?: any, timeout?: number): Promise<string | Array<any> | any>,
  LoadScriptFromString(scriptCode: string): any
}

interface Utils {
  GetMainHUD(): Panel
  SetCameraDistance(camDistance: number): void
  SetCameraPitch(angle: number): void
  SetCameraYaw(camYaw: number): void
  SetFogOff(): void
  SetFogOn(): void
  EvalLuaCode(code: string): void
  SetConvar(key: string, value: any): void
  UnrestrictedCmd(command: string): void
  InstallStyle(panel: Panel, stylesString: string): void
}

interface MainMenu {
  CreateButton(): void
  CreateMainMenu(): void
  Reload(): void
}

interface Module {
  onDestroy(): Promise<any> | void;
  onInit(): Promise<any> | void;
}

interface CDOTA_PanoramaScript_GameEvents {
  SendEventClientSide<TName extends keyof GameEventDeclarations>(
    pEventName: TName,
    eventData: GameEventDeclarations[TName] | any,
  ): void;
}

interface DollarStatic {
  Msg_old(...args: any[]): void;
}