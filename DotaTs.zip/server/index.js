const fs = require('fs');
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser')

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

const api = {
  getinitscript: async (data, response) => {
    data = fs.readFileSync(path.join(__dirname, './../build/main/body.js'))
    response.setHeader("Content-Type", "application/javascript");
    response.send(data);
  },
  log: (data, response) => {
    var report = {
			script: data.path,
			msg: data.value
		}
		console.log(`${report.script } ${report.msg}`)
		response.sendStatus(200)
  }
}

app.post('/', async (request, response) => {
  try {
    const data = request.body;
    if (!data || !data.name || data.name === '') {
      return response.sendStatus(400);
    }

    const handler = api[data.name];
    if (!handler) {
      return response.sendStatus(404)
    }

    await handler(data, response)
  } catch (error) {
    console.error('error: ', error)
    response.status(503).send(JSON.stringify(error))
  }
});

app.listen(4297, () => {
  console.log('DotaTS server listening on port 4297!');
});
