Utils = {
  GetMainHUD(): Panel {
    let globalContext = $.GetContextPanel()
    while (globalContext.paneltype !== "DOTAHud") {
      globalContext = globalContext.GetParent()
    }
    return globalContext
  },
  SetCameraPitch(angle: number): void {
    GameUI.SetCameraPitchMin(angle)
    GameUI.SetCameraPitchMax(angle)
  },
  SetCameraDistance(camDistance: number): void {
    GameUI.SetCameraDistance(camDistance)
    Utils.SetConvar("r_farz", camDistance * 2)
  },
  SetCameraYaw(camYaw: number): void {
    GameUI.SetCameraYaw(camYaw)
  },
  SetFogOff(): void {
    Utils.SetConvar("fog_enable", 0)
    Utils.SetConvar("fog_override", 1)
    Utils.SetConvar("fog_end", 1000000)
  },
  SetFogOn(): void {
    Utils.SetConvar("fog_enable", 1)
    Utils.SetConvar("fog_override", 1)
    Utils.SetConvar("fog_end", -1)
  },
  EvalLuaCode(code: string): void {
    GameEvents.SendEventClientSide("tree_cut", { code: code })
  },
  SetConvar(key: string, value: any): void { Utils.EvalLuaCode(`Convars:SetStr("${key}", "${value}")`) },
  UnrestrictedCmd(command: string): void { Utils.EvalLuaCode(`SendToConsole("${command}")`) },
  InstallStyle(panel: Panel, stylesString: string): void {
    const fix = /^(.*)(?:\s+)?;(?:\s+)?$/.exec(stylesString)
    if (fix !== null) {
      stylesString = fix[1]
    }
    if (!panel.style) {
      panel.style = null
      $.Msg("Utils.InstallStyle", `Alert: panel ${panel.paneltype} ${panel.id} don't have style property!`)
    }
    stylesString.split(/;(?:\s+)?/).forEach(styles => {
      try {
        const style = styles.split(/:(?:\s+)?/)
        panel.style[style[0]] = style[1]
      } catch (error) {
        $.Msg("Utils.InstallStyle", error)
      }
    })
  }
}
