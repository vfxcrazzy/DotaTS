DotaTS.Panels.Main = Utils.GetMainHUD()
DotaTS.Panels.Main.GameEndContainer = DotaTS.Panels.Main.FindChildInLayoutFile('GameEndContainer')
DotaTS.Panels.Main.HUDElements = DotaTS.Panels.Main.FindChild('HUDElements')
DotaTS.Panels.Main.PopupManager = DotaTS.Panels.Main.FindChild('PopupManager')
DotaTS.Panels.Main.HUDElements.MenuButtons = DotaTS.Panels.Main.HUDElements.FindChild('MenuButtons')
DotaTS.Panels.Main.HUDElements.MenuButtons.ButtonBar = DotaTS.Panels.Main.HUDElements.MenuButtons.FindChild('ButtonBar')

DotaTS.Panels.DotaTS = {
  Menu: $.CreatePanel('Panel', DotaTS.Panels.Main.PopupManager, 'PopupDotaTS'),
  Button: $.CreatePanel('Button', DotaTS.Panels.Main.HUDElements.MenuButtons.ButtonBar, 'TogglePannelButton')
}

MainMenu = {
  CreateButton: (): void => {
    $.Msg('[DotaTS] Load Button <------------------------------------------------------------')
    DotaTS.Panels.DotaTS.Button.BLoadLayoutFromString(`
      <root>\
        <Button style="background-image: url('s2r://panorama/images/control_icons/guild_leader_png.vtex'); background-size: 26px;"/>\
      </root>
    `, false, false)

    DotaTS.Panels.DotaTS.Button.SetPanelEvent('onactivate', () => {
      DotaTS.Panels.DotaTS.Menu.visible = !DotaTS.Panels.DotaTS.Menu.visible
      if (DotaTS.Panels.DotaTS.Menu.visible) {
        $.DispatchEvent('PlaySoundEffect', 'ui_menu_activate_open');
      } else {
        $.DispatchEvent('PlaySoundEffect', 'ui_menu_activate_close');
      }
    })
  },

  Reload: (): void => {
    $.Msg('[DotaTS] Realod <------------------------------------------------------------')
    DotaTS.Panels.DotaTS.DeleteAsync(0)
    delete DotaTS.Panels.DotaTS
  },

  CreateMainMenu: (): void => {
    $.Msg('[DotaTS] Load Main <------------------------------------------------------------')
    DotaTS.Panels.DotaTS.Menu.BLoadLayoutFromString(`
    <root>\
  <styles>
    <include src="s2r://panorama/styles/dotastyles.vcss_c" />
    <include src="s2r://panorama/styles/popups/popups_shared.vcss_c" />
    <include src="s2r://panorama/styles/battle_pass/current_battle_pass.vcss_c" />
    <include src="s2r://panorama/styles/popups/popup_settings.vcss_c" />
  </styles>

  <script type="text/css">
    .ControlIconButton:hover {
      wash-color: #939da0;
    }

    .ControlIconButton:active {
      sound: "ui_settings_out_multi";
    }
  </script>

  <script>
    $.Msg('[DotaTS] Main Menu Loaded <------------------------------------------------------------')
    function changeActiveTab(nTab) {
      $('#DotaTSMainTabContent').visible = false;
      $('#DotaTSScriptsTabContent').visible = false;
      $('#DotaTSAboutTabContent').visible = false;

      switch (nTab) {
        case 0:
          $('#DotaTSMainTabContent').visible = true;
          break;
        case 1:
          $('#DotaTSScriptsTabContent').visible = true;
          break;
        case 2:
          $('#DotaTSAboutTabContent').visible = true;
          break;
        default:
          $('#DotaTSMainTabContent').visible = true;
      }
    }
    changeActiveTab();

    function closePopup() {
      $.DispatchEvent('PlaySoundEffect', 'ui_menu_activate_close');
      $('#PopupDotaTS').visible = false;
    }
  </script>

  <PopupSettings defaultfocus="TestContainer" popupbackground="blur" oncancel="closePopup()"
    style="width: 1588px; height: 920px; vertical-align: center; horizontal-align: center; opacity: 1.0; transform: none; perspective-origin: 62% 5% invert; perspective: 1000; transition-property: opacity, transform, pre-transform-scale2d, wash-color; transition-duration: 0.4s; transition-delay: 0.0s; transition-timing-function: ease-in-out; background-color: gradient( linear, 0% 0%, 0% 25%, from( #232326 ), to( #1c1d20 ) ); box-shadow: #00000099 -4px -4px 8px 8px; border: 2px solid #32383677;">

    <Panel id="SettingsNavBar">
      <Button id="DOTACloseSettingsButton" class="ControlIconButton" style="margin-right: 10px;" onactivate="closePopup()" />
      <Button id="DOTAReloadButton" class="ControlIconButton" onactivate="closePopup()" style="background-image: url('s2r://panorama/images/control_icons/refresh_psd.vtex'); margin-left: 6px; margin-top: 6px; width: 32px; height: 32px; background-size: contain; background-position: 50% 50%; background-repeat: no-repeat; horizontal-align: right; margin-right: 28px; wash-color: #575d5f;" />
      <RadioButton id="DotaTSMainTabButton" class="SettingsNavBarButton" group="SettingsTopMenu" onactivate="changeActiveTab( 0 )">
        <Label text="Main" />
      </RadioButton>
      <Label class="SettingsTabSeparator" text="/" />
      <RadioButton id="DotaTSScriptsTabButton" class="SettingsNavBarButton" group="SettingsTopMenu" onactivate="changeActiveTab( 1 )">
        <Label text="Scripts" />
      </RadioButton>
      <Panel class="SettingsTabFiller" />
      <RadioButton id="DotaTSAboutTabButton" class="SettingsNavBarButton" group="SettingsTopMenu" onactivate="changeActiveTab( 2 )">
        <Label text="DotaTS" />
      </RadioButton>
    </Panel>

    <Panel id="DotaTSMainTabContent" class="SettingsSecondaryPanel">
      <Panel class="SettingsColumnContainer FullHeight" id="DotaTSMainSettings">
        <Panel id="Column0" class="SettingsColumn">
          <Panel id="MenuOptions" class="SettingsSection">
            <Label text="Menu" class="SectionHeader" />
            <Panel class="SectionHeaderLineNoMargin" />
            <DOTASettingsKeyBinder id="__TogglePannel" text="Open/Hide Menu" bind="__TogglePannel" />
            <DOTASettingsKeyBinder id="__ReloadPannel" text="Reload Menu and Scripts" bind="__ReloadPannel" />

            <Label text="Camera" class="SectionHeader" />
            <Panel class="SectionHeaderLine" />
            <DOTASettingsCheckbox style="visibility: collapse;" id='Cheats' convar='sv_cheats' text="Enable cheats" />
            <DOTASettingsCheckbox style="visibility: collapse;" id='RecordCommands' convar='demo_recordcommands' text="Record commands typed at console" />
            <DOTASettingsCheckbox style="visibility: collapse;" id='NewPlayer' convar='dota_new_player' text="New player" />
            <DOTASettingsSlider style="margin-left: 20px;" id='CameraDistance' min='1200.0' max='4000.0' text='Distance' />
            <DOTASettingsSlider style="visibility: collapse;" id='CameraDistanceFarZ' convar='r_farz' min='2200.0' max='8000.0' text='Distance Far Z' />
            <DOTASettingsSlider style="margin-left: 20px;" id='CameraPitch' min='-1.0' max='360.0' text='Pitch (Rotation Y)' />
            <DOTASettingsSlider style="margin-left: 20px;" id='CameraYaw' min='0.0' max='360.0' text='Yaw (Rotation Z)' />

            <Label text="Environment" class="SectionHeader" />
            <Panel class="SectionHeaderLine" />
          </Panel>
        </Panel>

        <Panel id="Column1" class="SettingsColumn">
          <Panel id="MapOptions" class="SettingsSection">
            <Label text="Map" class="SectionHeader" />
            <Panel class="SectionHeaderLine" />
            <DOTASettingsCheckbox id='FogOptions' convar='fog_enable' text="Fog" />

            <DOTASettingsCheckbox id='FogFilterOptions' convar='fow_client_nofiltering' text="Fog filter" />

            <DOTASettingsCheckbox id='ParticleFowOptions' convar='dota_use_particle_fow' text="Particle fow" />

            <DOTASettingsCheckbox id='GridNavOptions' convar='cl_dota_gridnav_show' text="Show/Hide Grid Nav" />

            <DOTASettingsCheckbox id='HeightMapOptions' convar='dota_show_heightmap' text="Show/Hide HeightMap" />

            <DOTASettingsCheckbox id='DrawPathsOptions' convar='dota_unit_draw_paths' text="Show/Hide Draw Paths" />

            <DOTASettingsCheckbox id='BoundingRadiusOptions' convar='dota_unit_show_bounding_radius' text="Show/Hide Bounding Radius" />

            <DOTASettingsCheckbox id='CollisionRadiusOptions' convar='dota_unit_show_collision_radius' text="Show/Hide Collision Radius" />

            <DOTASettingsCheckbox id='ObjectObstructionsOptions' convar='dota_show_object_obstructions' text="Show/Hide object obstructions" />

            <DOTASettingsEnum id="FowClientVisibilityOptions" convar="fow_client_visibility" text="Visibility">
              <RadioButton text="Normal" value="0" class="EnumButton" group="weather_effects" />
              <RadioButton text="All" value="1" class="EnumButton" group="weather_effects" />
              <RadioButton text="None" value="2" class="EnumButton" group="weather_effects" />
            </DOTASettingsEnum>

            <DOTASettingsEnum id="WeatherEffectsOptions" convar="cl_weather" text="Weather effects">
              <RadioButton text="Default" value="0" class="EnumButton" group="weather_effects" />
              <RadioButton text="Snow" value="1" class="EnumButton" group="weather_effects" />
              <RadioButton text="Rain" value="2" class="EnumButton" group="weather_effects" />
              <RadioButton text="Spring" value="3" class="EnumButton" group="weather_effects" />
              <RadioButton text="Pestilence" value="4" class="EnumButton" group="weather_effects" />
              <RadioButton text="Harvest" value="5" class="EnumButton" group="weather_effects" />
              <RadioButton text="Sirocco" value="6" class="EnumButton" group="weather_effects" />
              <RadioButton text="Moonbeam" value="7" class="EnumButton" group="weather_effects" />
              <RadioButton text="Ash" value="8" class="EnumButton" group="weather_effects" />
              <RadioButton text="Aurora" value="9" class="EnumButton" group="weather_effects" />
            </DOTASettingsEnum>

            <DOTASettingsEnum id="DrawsSelectionHitboxesOptions" convar="dota_unit_show_selection_boxes" text="Draws selection hitboxes">
              <RadioButton text="Off" value="0" class="EnumButton" group="weather_effects" />
              <RadioButton text="Non trees" value="1" class="EnumButton" group="weather_effects" />
              <RadioButton text="Trees" value="2" class="EnumButton" group="weather_effects" />
              <RadioButton text="All entities" value="3" class="EnumButton" group="weather_effects" />
            </DOTASettingsEnum>
          </Panel>
        </Panel>

        <Panel id="Column2" class="SettingsColumn">
          <Label text="c" />
        </Panel>
      </Panel>
    </Panel>

    <Panel id="DotaTSScriptsTabContent" class="SettingsSecondaryPanel">
      <Panel class="SettingsColumnContainer FullHeight" id="DotaTSMainSettings">
        <Label text="DotaTS" />
      </Panel>
    </Panel>

    <Panel id="DotaTSAboutTabContent" class="SettingsSecondaryPanel">
      <Panel class="SettingsColumnContainer FullHeight" id="DotaTSMainSettings">
        <Label text="DotaTS" />
      </Panel>
    </Panel>
  </PopupSettings>
</root>
    `, false, false)

    DotaTS.Panels.DotaTS.Menu.Cheats = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("Cheats")
    DotaTS.Panels.DotaTS.Menu.Cheats.value = true

    DotaTS.Panels.DotaTS.Menu.RecordCommands = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("RecordCommands")
    DotaTS.Panels.DotaTS.Menu.RecordCommands = false

    DotaTS.Panels.DotaTS.Menu.NewPlayer = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("NewPlayer")
    DotaTS.Panels.DotaTS.Menu.NewPlayer = false

    DotaTS.Panels.DotaTS.Menu.CameraDistance = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("CameraDistance")
    DotaTS.Panels.DotaTS.Menu.CameraDistanceFarZ = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("CameraDistanceFarZ")
    DotaTS.Panels.DotaTS.Menu.CameraDistance.SetPanelEvent("onvaluechanged", () => {
      const CameraDistanceValue = (4000 - 1200) * DotaTS.Panels.DotaTS.Menu.CameraDistance.value + 1200
      DotaTS.Panels.DotaTS.Menu.CameraDistanceFarZ.value = DotaTS.Panels.DotaTS.Menu.CameraDistance.value
      Utils.SetCameraDistance(CameraDistanceValue)
    })

    DotaTS.Panels.DotaTS.Menu.CameraPitch = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("CameraPitch")
    DotaTS.Panels.DotaTS.Menu.CameraPitch.SetPanelEvent("onvaluechanged", () => {
      const CameraPitchValue = (360 - (-1)) * DotaTS.Panels.DotaTS.Menu.CameraPitch.value + (-1)
      Utils.SetCameraPitch(CameraPitchValue)
    })

    DotaTS.Panels.DotaTS.Menu.CameraYaw = DotaTS.Panels.DotaTS.Menu.FindChildInLayoutFile("CameraYaw")
    DotaTS.Panels.DotaTS.Menu.CameraYaw.SetPanelEvent("onvaluechanged", () => {
      const CameraPitchValue = (360 - (-1)) * DotaTS.Panels.DotaTS.Menu.CameraYaw.value + (-1)
      Utils.SetCameraYaw(CameraPitchValue)
    })

    Game.AddCommand("__TogglePannel", () => DotaTS.Panels.DotaTS.Menu.visible = !DotaTS.Panels.DotaTS.Menu.visible, "",0)
    Game.CreateCustomKeyBind('HOME', "__TogglePannel")
    Game.AddCommand("__ReloadPannel", () => MainMenu.Reload, "",0)
    Game.CreateCustomKeyBind("End", "__ReloadPannel")
  }
}
