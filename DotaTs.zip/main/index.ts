DotaTS = {
  Panels: {},
  Init: async () => {
    try {
      $.Msg('[DotaTS] Init <------------------------------------------------------------')
      GameEvents.Subscribe('dota_game_state_change', () => {
        if (Game.GameStateIsAfter(DOTA_GameState.DOTA_GAMERULES_STATE_HERO_SELECTION) && Game.GameStateIsBefore(DOTA_GameState.DOTA_GAMERULES_STATE_POST_GAME)) {
          $.Msg('[DotaTS] in Game <------------------------------------------------------------')
          MainMenu.CreateButton()
          MainMenu.CreateMainMenu()
        }
      })
    } catch (error) {
      $.Msg('[DotaTS] Init - Error: ', error)
    }
  },
  GetServer: () => {
    return 'http://localhost:4297'
  },
  LoadScriptFromString: (scriptCode: string) => {
    try {
      $.Msg('[DotaTS] LoadScriptFromString')
      eval(<string>scriptCode)
    } catch (error) {
      $.Msg('[DotaTS] LoadScriptFromString - Error: ', error)
    }
  },
  ServerRequest: (name?: string, path?: string, value?: any, timeout = 500) => new Promise(resolve => {
    const args = {
      type: "POST",
      data: {
        name: name,
        path: path,
        value: value
      },
      timeout: timeout,
      success: resolve,
      error: response => {
        if (response.status !== 403) {
          $.AsyncWebRequest(DotaTS.GetServer(), args)
        } else {
          resolve('')
        }
      }
    }

    $.AsyncWebRequest(DotaTS.GetServer(), args)
  })
}

DotaTS.Init()