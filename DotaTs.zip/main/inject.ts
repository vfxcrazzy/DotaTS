if(!$.Msg_old) {
	$.Msg_old = $.Msg
	$.Msg = (tag: string, ...msg: any[]): void => {
		if(msg.length === 0) {
			msg = [tag]
			tag = "DotaTS"
		}
		$.Msg_old(`[${tag}] `, ...msg.map(msg_ => msg_.toString()))
		DotaTS.ServerRequest("log", tag, ...msg.map(msg_ => msg_.toString()), 0)
	}
}